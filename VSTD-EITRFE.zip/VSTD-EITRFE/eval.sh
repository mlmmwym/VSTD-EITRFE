CUDA_VISIBLE_DEVICES=0 python3 tools/eval.py --model_path './output/model_path'
