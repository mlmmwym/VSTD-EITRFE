import os

folder_path = './datasets/train/train_gts'  # 替换成你的文件夹路径

# 获取文件夹中所有的文件名
file_names = [f for f in os.listdir(folder_path) if f.endswith('.txt')]

# 遍历文件并重命名
for file_name in file_names:
    # 构建旧文件路径和新文件路径
    old_path = os.path.join(folder_path, file_name)
    new_file_name = file_name.replace('gt_', '')  # 删除前缀
    new_path = os.path.join(folder_path, new_file_name)

    # 重命名文件
    os.rename(old_path, new_path)

print("文件重命名完成。")
