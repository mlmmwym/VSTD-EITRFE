import torch
from torch import nn
import numpy as np

from models.basic import ConvBnRelu
class Sobelxy(nn.Module):
    def __init__(self,channels, kernel_size=3, padding=1, stride=1, dilation=1, groups=1):
        super(Sobelxy, self).__init__()
        sobel_filter = np.array([[1, 0, -1],
                                 [2, 0, -2],
                                 [1, 0, -1]])
        self.convx = nn.Conv2d(channels, channels, kernel_size=kernel_size, padding=padding, stride=stride, dilation=dilation, groups=channels,bias=False)
        self.convx.weight.data.copy_(torch.from_numpy(sobel_filter))
        self.convy = nn.Conv2d(channels, channels, kernel_size=kernel_size, padding=padding, stride=stride, dilation=dilation, groups=channels,bias=False)
        self.convy.weight.data.copy_(torch.from_numpy(sobel_filter.T))
    def forward(self, x):
        sobelx = self.convx(x)
        sobely = self.convy(x)
        x=torch.abs(sobelx) + torch.abs(sobely)
        return x

class Sobelxy(nn.Module):
    def __init__(self,channels, kernel_size=3, padding=1, stride=1, dilation=1, groups=1):
        super(Sobelxy, self).__init__()
        sobel_filter = np.array([[1, 0, -1],
                                 [2, 0, -2],
                                 [1, 0, -1]])
        self.convx = nn.Conv2d(channels, channels, kernel_size=kernel_size, padding=padding, stride=stride, dilation=dilation, groups=channels,bias=False)
        self.convx.weight.data.copy_(torch.from_numpy(sobel_filter))
        self.convy = nn.Conv2d(channels, channels, kernel_size=kernel_size, padding=padding, stride=stride, dilation=dilation, groups=channels,bias=False)
        self.convy.weight.data.copy_(torch.from_numpy(sobel_filter.T))
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=2, padding=1)
        # self.conv3 = conv_downsample = nn.Conv2d(3, 3, kernel_size=4, stride=4, padding=0)
        # self.conv1 = nn.Conv2d(3, 64, kernel_size=1)
    def forward(self, x):
        sobelx = self.convx(x)  # [16, 3, 640, 640]
        sobely = self.convy(x)  # [16, 3, 640, 640]
        x = torch.abs(sobelx) + torch.abs(sobely) # [16, 3, 640, 640]
        x = self.conv1(x)   # [16, 64, 320, 320]
        x = self.conv3(x)       # [16, 64, 160, 160]
        # x = self.conv3(x)   # [16, 3, 160, 160]
        # x = self.conv1(x)   # [16, 64, 160, 160]
        return x