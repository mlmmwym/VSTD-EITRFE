import torch.nn as nn
import torch.nn.functional as F
import torch

class StripPooling(nn.Module):
    def __init__(self, in_channels, up_kwargs={'mode': 'bilinear', 'align_corners': True}):
        super(StripPooling, self).__init__()
        self.conv_1 = ConvBlock(in_channels=in_channels, out_channels=in_channels, res_conv=True, stride=1)
        self.pool1 = nn.AdaptiveAvgPool2d((1, None))  # 1*W
        self.pool2 = nn.AdaptiveAvgPool2d((None, 1))  # H*1
        inter_channels = int(in_channels / 4)
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels, inter_channels, 1, bias=False),
                                   nn.BatchNorm2d(inter_channels),
                                   nn.ReLU(True))
        self.conv2 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, (1, 3), 1, (0, 1), bias=False),
                                   nn.BatchNorm2d(inter_channels))
        self.conv3 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, (3, 1), 1, (1, 0), bias=False),
                                   nn.BatchNorm2d(inter_channels))
        self.conv4 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, 3, 1, 1, bias=False),
                                   nn.BatchNorm2d(inter_channels),
                                   nn.ReLU(True))
        self.conv5 = nn.Sequential(nn.Conv2d(inter_channels, in_channels, 1, bias=False),
                                   nn.BatchNorm2d(in_channels))
        self._up_kwargs = up_kwargs
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        _, _, h, w = x.size()  # h:20 w:20 _:2048 [2, 2048, 20, 20]
        x = self.conv_1(x, return_x_2=False)    # [2, 2048, 20, 20]
        x1 = self.conv1(x)  # [2, 512, 20, 20]
        x2 = F.interpolate(self.conv2(self.pool1(x1)), (h, w),
                           **self._up_kwargs)  # 结构图的1*W的部分    # [2, 512, 20, 20]
        x3 = F.interpolate(self.conv3(self.pool2(x1)), (h, w),
                           **self._up_kwargs)  # 结构图的H*1的部分    # [2, 512, 20, 20]
        x4 = self.conv4(F.relu_(x2 + x3))  # 结合1*W和H*1的特征  # [2, 512, 20, 20]
        x5 = self.conv5(x4)  # [2, 512, 20, 20]
        out = self.sigmoid(x5)
        x = F.relu_(x + x * out)    # [2, 2048, 20, 20]

        return x  # 将输出的特征与原始输入特征结合

# class StripPooling(nn.Module):
#     def __init__(self, in_channels, up_kwargs={'mode': 'bilinear', 'align_corners': True}):
#         super(StripPooling, self).__init__()
#         self.pool1 = nn.AdaptiveAvgPool2d((1, None))#1*W
#         self.pool2 = nn.AdaptiveAvgPool2d((None, 1))#H*1
#         inter_channels = int(in_channels / 4)
#         self.conv1 = nn.Sequential(nn.Conv2d(in_channels, inter_channels, 1, bias=False),
#                                      nn.BatchNorm2d(inter_channels),
#                                      nn.ReLU(True))
#         self.conv2 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, (1, 3), 1, (0, 1), bias=False),
#                                      nn.BatchNorm2d(inter_channels))
#         self.conv3 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, (3, 1), 1, (1, 0), bias=False),
#                                      nn.BatchNorm2d(inter_channels))
#         self.conv4 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, 3, 1, 1, bias=False),
#                                      nn.BatchNorm2d(inter_channels),
#                                      nn.ReLU(True))
#         self.conv5 = nn.Sequential(nn.Conv2d(inter_channels, in_channels, 1, bias=False),
#                                    nn.BatchNorm2d(in_channels))
#         self._up_kwargs = up_kwargs
#         self.sigmoid = nn.Sigmoid()
#
#     def forward(self, x):
#         _, _, h, w = x.size()   # h:640 w:640 _:256 [16, 256,640,640]
#
#         x1 = self.conv1(x)  # [16, 64, 640, 640]
#         x2 = F.interpolate(self.conv2(self.pool1(x1)), (h, w), **self._up_kwargs)#结构图的1*W的部分    # [16, 64, 640, 640]
#         x3 = F.interpolate(self.conv3(self.pool2(x1)), (h, w), **self._up_kwargs)#结构图的H*1的部分    # [16, 64, 640, 640]
#         x4 = self.conv4(F.relu_(x2 + x3))#结合1*W和H*1的特征  # [16, 64, 640, 640]
#         x5 = self.conv5(x4)    # [16, 256,640,640]
#         out = self.sigmoid(x5)
#
#         return x * out #将输出的特征与原始输入特征结合

if __name__ == '__main__':
    models = StripPooling(256, up_kwargs={'mode': 'bilinear', 'align_corners': True})
    print(models)
    inputs = torch.ones([16, 256, 640, 640])
    out = models(inputs)