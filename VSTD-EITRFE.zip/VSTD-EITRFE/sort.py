import os
import shutil

def extract_number(file_name):
    return int(''.join(filter(str.isdigit, file_name)))

def sort_and_move_txt_files(folder_path):
    # 获取文件夹中所有的文件名
    file_names = [f for f in os.listdir(folder_path) if f.endswith('.txt')]

    # 对文件名按数字从小到大排序
    sorted_file_names = sorted(file_names, key=extract_number)

    # 新建一个文件夹用于存放排序后的文件
    sorted_folder_path = './datasets/train/gt'  # 替换成你想要存放文件的文件夹路径
    os.makedirs(sorted_folder_path, exist_ok=True)

    # 打印排序后的文件名并移动文件
    for idx, file_name in enumerate(sorted_file_names):
        print(file_name)
        old_path = os.path.join(folder_path, file_name)
        new_path = os.path.join(sorted_folder_path, f'{idx + 1}_{file_name}')
        shutil.move(old_path, new_path)

    print(f"文件移动完成，排序后的文件存放在 {sorted_folder_path}。")

# 替换成你的文件夹路径
folder_path = './datasets/train/train_gts'
sort_and_move_txt_files(folder_path)
