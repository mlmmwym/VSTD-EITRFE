import torch.cuda

print(torch.cuda.is_available())


