import torch
import torchvision.transforms as transforms
from PIL import Image
import matplotlib.pyplot as plt
import os
import models
from models import *
from data_loader import get_transforms
from models import build_model
from post_processing import get_post_processing

class Pytorch_model:
    def __init__(self, model_path, post_p_thre=0.7, gpu_id=None):
        '''
        初始化pytorch模型
        :param model_path: 模型地址(可以是模型的参数或者参数和计算图一起保存的文件)
        :param gpu_id: 在哪一块gpu上运行
        '''
        self.gpu_id = gpu_id

        if self.gpu_id is not None and isinstance(self.gpu_id, int) and torch.cuda.is_available():
            self.device = torch.device("cuda:%s" % self.gpu_id)
        else:
            self.device = torch.device("cpu")
        print('device:', self.device)
        checkpoint = torch.load(model_path, map_location=self.device)

        config = checkpoint['config']
        config['arch']['backbone']['pretrained'] = False
        self.model = build_model(config['arch'])
        self.post_process = get_post_processing(config['post_processing'])
        self.post_process.box_thresh = post_p_thre
        self.img_mode = config['dataset']['train']['dataset']['args']['img_mode']
        self.model.load_state_dict(checkpoint['state_dict'])
        self.model.to(self.device)
        self.model.eval()

        self.transform = []
        for t in config['dataset']['train']['dataset']['args']['transforms']:
            if t['type'] in ['ToTensor', 'Normalize']:
                self.transform.append(t)
        self.transform = get_transforms(self.transform)

def init_args():
    import argparse
    parser = argparse.ArgumentParser(description='DBNet.pytorch')
    parser.add_argument('--model_path', default='output/250_all_2403081023/DBNet_resnet50_FPN_DBHead_resnet50_FPN_DBHead/checkpoint/model_best.pth', type=str)
    parser.add_argument('--input_folder', default='./test/input', type=str, help='img path for predict')
    parser.add_argument('--output_folder', default='./test/output', type=str, help='img path for output')
    parser.add_argument('--thre', default=0.3, type=float, help='the thresh of post_processing')
    parser.add_argument('--polygon', action='store_true', help='output polygon or box')
    parser.add_argument('--show', action='store_true', help='show result')
    parser.add_argument('--save_result', action='store_true', help='save box and score to txt file')
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    import pathlib
    from tqdm import tqdm
    import matplotlib.pyplot as plt
    from utils.util import show_img, draw_bbox, save_result, get_file_list

    args = init_args()
    print(args)
    os.environ['CUDA_VISIBLE_DEVICES'] = str('0')
    # 初始化网络
    # model_path训练好的模型地址还有配置参数
    model = Pytorch_model(args.model_path, post_p_thre=args.thre, gpu_id=0)
    model.model.load_state_dict(torch.load("output/250_all_2403081023/DBNet_resnet50_FPN_DBHead_resnet50_FPN_DBHead/checkpoint/model_best.pth"), strict=False)
    # 加载并预处理输入图像
    image_path = "im1727.jpg"
    image = Image.open(image_path).convert("RGB")
    preprocess = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])
    input_image = preprocess(image).unsqueeze(0)
    input_image=input_image.cuda()
    # 将输入图像传递到模型，记录 layer1 层的输出
    model.model.eval()
    input_image1 = model.model.backbone.sobel(input_image)
    input_image = model.model.backbone.conv1(input_image)
    input_image = model.model.backbone.bn1(input_image)
    input_image = model.model.backbone.relu(input_image)

    input_image = model.model.backbone.maxpool(input_image)

    input_image = input_image + input_image1
    input_image = model.model.backbone.layer1[0](input_image)
    with torch.no_grad():
        features = model.model.backbone.layer1[1](input_image)

    # 提取 layer1 层的输出特征图
    feature_maps = features.squeeze(0).permute(1, 2, 0).cpu().numpy()

    # 可视化特征图
    plt.figure(figsize=(8, 6))  # 调整显示图像的大小
    plt.imshow(feature_maps[:, :, 0], cmap='gray')
    plt.axis('off')
    plt.show()

    # 保存特征图到指定文件夹
    output_folder = "./feature_maps_visualization/layer1_1"
    pathlib.Path(output_folder).mkdir(parents=True, exist_ok=True)  # 创建输出文件夹
    output_file = os.path.join(output_folder, "feature_map_1727_0.png")  # 输出文件路径
    plt.imsave(output_file, feature_maps[:, :, 0], cmap='gray', dpi=300)  # 保存特征图
    print("Feature map saved at:", output_file)
